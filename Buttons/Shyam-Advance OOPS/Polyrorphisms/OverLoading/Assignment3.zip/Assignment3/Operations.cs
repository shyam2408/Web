using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3
{
    public class Operations
    {
        /*Compute square of given integer
        Compute square of given float
        Compute square of given double
        Compute square of given long*/
        public double DisplayResult(int number)
        {
            return Math.Pow(number,number);
        }
        public double DisplayResult(float number)
        {
            return Math.Pow(number,number);
        }
        public double DisplayResult(double number)
        {
            return Math.Pow(number,number);
        }
        public double DisplayResult(long number)
        {
            return Math.Pow(number,number);
        }
    }
}