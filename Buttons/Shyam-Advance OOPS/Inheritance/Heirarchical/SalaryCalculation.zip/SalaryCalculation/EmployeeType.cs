namespace SalaryCalculation
{
    public enum EmployeeType
    {
        Permananet,Temporary
    }
}