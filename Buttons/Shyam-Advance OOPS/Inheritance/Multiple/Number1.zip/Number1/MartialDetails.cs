namespace Number1
{
    public enum MartialStatus
    {
        Unkown,Single,Married
    }
}